
// CLICK 1
$(document).ready(function(){
    $('#click1').click(function(){
        $('#responses').append('Because I was forced to');
    });
  });

// CLICK 2
  $(document).ready(function(){
      $('#click2').click(function(){
          $('#responses').append('I am not sure why');
      });
    });

// Send sound on click 1&2



// Message sound for michelleresponse
